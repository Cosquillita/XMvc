﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;
using System.Collections;
using System.Linq.Expressions;
using System.IO;

namespace XMvcScaffoldingForOracle
{
    public class RelatedEntity
    {
        public Form1.MultiplicityType tableMultiplicity = Form1.MultiplicityType.none;
        public string tableName = "";
        public string columnName = "";
        public Form1.RelationshipType relatedTableType = Form1.RelationshipType.none;
        public Form1.MultiplicityType relatedTableMultiplicity = Form1.MultiplicityType.none;
        public string relatedTableName = "";
        public string relatedColumnName = "";
        public string relatedDisplayColumnName = "";
    }

    public class RelatedEntityHelpers
    {
        // dictionary lookup string will be the columnName
        // the RelatedEntity object has lots of info
        public Dictionary<string, RelatedEntity> GetRelatedEntities(string modelName, XElement edmxConceptualSchema)
        {
            Dictionary<string, RelatedEntity> result = new Dictionary<string, RelatedEntity>();
            IEnumerable<XElement> modelItems = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == "EntityType" && m.Attribute("Name").Value.ToString() == modelName);
            foreach (var item in modelItems)
            {
                var navProps = item.Elements().Where(m => m.Name.LocalName == "NavigationProperty");
                foreach (var navProp in navProps)
                {
                    // fromRole is always the modelName ?... looks like it is.
                    string fromRole = navProp.Attributes().Where(n => n.Name.LocalName == "FromRole").First().Value.ToString();
                    string toRole = navProp.Attributes().Where(n => n.Name.LocalName == "ToRole").First().Value.ToString();
                    string relationship = navProp.Attribute("Relationship").Value.ToString().Replace("Model.", "");
                    string navName = navProp.Attribute("Name").Value.ToString();

                    XElement associationItem = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == "Association" && m.Attribute("Name").Value.ToString() == relationship).First();
                    XElement modelRole = associationItem.Elements().Where(m => m.Name.LocalName == "End" && m.Attribute("Role").Value.ToString() == fromRole).First();
                    XElement relatedRole = associationItem.Elements().Where(m => m.Name.LocalName == "End" && m.Attribute("Role").Value.ToString() == toRole).First();

                    XElement referentialConstraint = associationItem.Elements().Where(m => m.Name.LocalName == "ReferentialConstraint").First();
                    XElement referentialPropForModel = referentialConstraint.Elements().Where(m => m.Attribute("Role").Value.ToString() == modelName).First();
                    XElement referentialPropForRelated = referentialConstraint.Elements().Where(m => m.Attribute("Role").Value.ToString() == toRole).First();

                    string columnName = referentialPropForModel.Elements().First().FirstAttribute.Value.ToString();
                    string relatedColumnName = referentialPropForRelated.Elements().First().FirstAttribute.Value.ToString();

                    RelatedEntity R = new RelatedEntity();
                    R.tableName = modelName;
                    R.columnName = columnName;
                    R.relatedTableName = toRole;
                    R.relatedColumnName = relatedColumnName;
                    R.tableMultiplicity = Form1.dictMultiplicities[modelRole.Attribute("Multiplicity").Value.ToString()];
                    R.relatedTableMultiplicity = Form1.dictMultiplicities[relatedRole.Attribute("Multiplicity").Value.ToString()];
                    R.relatedTableType = SetRelatedTableType(R.tableMultiplicity, R.relatedTableMultiplicity, referentialPropForModel, referentialPropForRelated);
                    if (R.relatedTableType == Form1.RelationshipType.parent)
                    {
                        // get the display column if the related entity is a parent. if none, leave blank.
                        XElement relatedItem = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == "EntityType" && m.FirstAttribute.Value.ToString() == toRole).First();
                        IEnumerable<XElement> displayColumns = relatedItem.Elements().Where(m => m.Name.LocalName == "Property" && m.FirstAttribute.Value.ToString() != relatedColumnName);
                        if (displayColumns.Count() >= 1)
                            R.relatedDisplayColumnName = displayColumns.First().FirstAttribute.Value.ToString();
                    }
                    result.Add(navName, R);
                }
            }
            return result;
        }

        private Form1.RelationshipType SetRelatedTableType(
            Form1.MultiplicityType tableMultiplicity, 
            Form1.MultiplicityType relatedTableMultiplicity,
            XElement referentialPropForModel,
            XElement referentialPropForRelated)
        {
            // && referentialPropForModel.Elements().Where(m => m.Name.LocalName == "Principal").Count() == 1 &&

            Form1.RelationshipType result = Form1.RelationshipType.none;

            if ((tableMultiplicity == Form1.MultiplicityType.one || tableMultiplicity == Form1.MultiplicityType.zeroOrOne) && (relatedTableMultiplicity == Form1.MultiplicityType.many || relatedTableMultiplicity == Form1.MultiplicityType.zeroOrMany))
            {
                result = Form1.RelationshipType.child;
            }
            else if ((tableMultiplicity == Form1.MultiplicityType.one || tableMultiplicity == Form1.MultiplicityType.zeroOrOne) && (relatedTableMultiplicity == Form1.MultiplicityType.one || relatedTableMultiplicity == Form1.MultiplicityType.zeroOrOne))
            {
                result = Form1.RelationshipType.sibling;
            }
            else if ((relatedTableMultiplicity == Form1.MultiplicityType.one || relatedTableMultiplicity == Form1.MultiplicityType.zeroOrOne) && (tableMultiplicity == Form1.MultiplicityType.many || tableMultiplicity == Form1.MultiplicityType.zeroOrMany))
            {
                result = Form1.RelationshipType.parent;
            }

            return result;
        }
    }
}
