﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Xml;
using System.Collections;
using System.Linq.Expressions;
using System.IO;

namespace XMvcScaffoldingForOracle
{
    public class XScaffolder
    {
        private void ScaffoldControllersAndViews(string projectPath, string projectName)
        {
            string edmxFileName = projectPath + @"\Models\Model1.edmx";
            XElement xfile = XElement.Load(edmxFileName);
            XElement edmxConceptualSchema = xfile.Elements().First().Elements().Where(m => m.Name.LocalName == "ConceptualModels").First().Elements().First();
            IEnumerable<XElement> items = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == "EntityType");
            foreach (var item in items)
                CreateController(item, edmxConceptualSchema, projectName, projectPath);
        }

        public string CreateController(XElement modelItem, XElement edmxConceptualSchema, string projectName, string projectPath)
        {
            string result = "";

            // setup the variables
            string modelName = modelItem.FirstAttribute.Value.ToString();
            string modelVariable = modelName.ToLower();
            if (modelVariable == "event") modelVariable = "eventt"; // fix for : event is a reserved word in C#
            string primaryKeyName = modelItem.Elements().Where(m => m.Name.LocalName == "Key").First().Elements().Where(m => m.Name.LocalName == "PropertyRef").First().FirstAttribute.Value.ToString();
            string primaryKeyType = GetPrimaryKeyType(modelItem, primaryKeyName);

            result = ReadTextFile(Application.StartupPath + @"\Scaffolders\Controllers\Controller.cs.txt");

            //Dictionary<string, RelatedEntity> parents = GetRelatedEntities(modelName, edmxConceptualSchema, RelationshipType.parent);

            //// these don't work... key is not unique... need another way to do this.
            //// Dictionary<string, RelatedEntity> children = GetRelatedEntities(modelName, edmxConceptualSchema, RelationshipType.child);
            //// Dictionary<string, RelatedEntity> siblings = GetRelatedEntities(modelName, edmxConceptualSchema, RelationshipType.sibling);
            //Dictionary<string, RelatedEntity> children = new Dictionary<string, RelatedEntity>();
            //Dictionary<string, RelatedEntity> siblings = new Dictionary<string, RelatedEntity>();

            //// add parent includes
            //List<string> parentIncludes = GetModelIncludes(modelName, edmxConceptualSchema);
            //string sParentIncludes = "";
            //foreach (string s in parentIncludes)
            //    sParentIncludes += string.Format(@".Include(m => m.{0})", s);
            //if (sParentIncludes == "")
            //    controller = controller.Replace(@"			<#= modelVariable => = <#= modelVariable =><#= parentTableIncludes =>;", "");
            //else
            //{
            //    sParentIncludes = @"			" + modelName.ToLower() + @" = " + modelName.ToLower() + sParentIncludes + ";";
            //    controller = controller.Replace(@"			<#= modelVariable => = <#= modelVariable =><#= parentTableIncludes =>;", sParentIncludes);
            //}

            //controller = controller.Replace(@"<#= primaryKeyType =>", primaryKeyType);

            //// add in select lists for __Create, __Edit, __Delete, ___Details, ___CreateOrEdit actions
            //Dictionary<string, string> selectListsForViewsDict = new Dictionary<string, string>();
            //controller = AddSelectListsToController(modelName, controller, parents, ref selectListsForViewsDict);

            //// replace vars not already replaced
            //controller = controller.Replace("<#= modelName =>", modelName).Replace("<#= modelVariable =>", modelVariable);
            //controller = controller.Replace("<#= primaryKeyName =>", primaryKeyName).Replace("<#= projectName =>", projectName).Replace('^', '"');

            //// since caret is used for replacements,
            //// defaultSorts in template use %
            //// change that back to a caret for the program logic
            //controller = controller.Replace("%1", "^1");

            //// write controller to file
            //WriteTextFile(projectPath + @"\Controllers\" + modelName + "Controller.cs", controller);
            //NewProjectItems.Add(string.Format(@"    <Compile Include=""Controllers\{0}Controller.cs"" />", modelName));

            //CreateViews(modelName, item, projectPath, modelVariable, primaryKeyName, columns, parents, children, siblings, selectListsForViewsDict, projectName);

            return result;
        }

        private string GetPrimaryKeyType(XElement modelItem, string primaryKeyName)
        {
            string result = "";
            foreach (XElement xe in modelItem.Elements().Where(m => m.Name.LocalName == "Property")) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value.ToString() == primaryKeyName)
                {
                    result = xe.Attribute("Type").Value.ToString().StartsWith("Int") ? "int" : "string";
                    break;
                }
            }
            return result;
        }

        private string ReadTextFile(string fileName)
        {
            string result = "";
            using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName))
            {
                result = sr.ReadToEnd();
            }
            return result;
        }
    }
}
