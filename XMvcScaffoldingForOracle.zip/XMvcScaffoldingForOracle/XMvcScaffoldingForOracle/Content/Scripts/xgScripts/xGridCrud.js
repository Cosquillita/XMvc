﻿
var actionCreate = "_Create";
var actionEdit = "_Edit";
var actionDelete = "_Delete";
var actionDeleteConfirmed = "_DeleteConfirmed";

function CrudGet(action, tableName, id, pageNum /* for Delete only, otherwise null */) {
    SpinnerShow();

    var sURL = "/" + tableName + "/" + action + "/"
    if (action === actionCreate) {
        sURL = "/" + tableName + "/" + action + "/" + id;
    } else if (action === actionDelete) {
        sURL = "/" + tableName + "/" + action + "/?id=" + id + "&pageNum=" + pageNum;
    }

    $.ajax({
        url: sURL,
        type: "GET"
    })
    .done(function (result) {
        $("#dialogContent").html(result);
        DialogShow();
        if (action !== actionDelete) {
            InitializeDatePickers();
        }
    })
    .fail(function (jqXHR, textStatus) {
        alert(action + "Request failed: " + textStatus);
    })
    .always(function () {
        SpinnerHide();
    });
}

function CrudCancel(event) {
    event.preventDefault(); // need this because buttons firing twice
    DialogHide();
}

function CrudPost(action, tableName, id /* for Insert, the id will be null */, pageNum /* for Delete only, otherwise null */, event) {
    event.preventDefault(); // need this because buttons firing twice
    SpinnerShow();
    var sURL = "/" + tableName + "/" + action + "/";
    var vars = $("form").serialize();

    $.ajax({
        url: sURL,
        type: "POST",
        data: vars
    })
    .done(function (result) {
        if (result.success === "true") {
            var filters = GatherFilters(tableName);
            var sorts = GatherSorts(tableName);
            SpinnerHide();
            DialogHide();
            if (action === actionCreate) {
                FilterSortPage(tableName, 0, filters, sorts, result.id);
            } else if (action === actionDeleteConfirmed) {
                FilterSortPage(tableName, pageNum, filters, sorts);
            } else {
                FilterSortPage(tableName, 0, filters, sorts, id);
            }
        } else {
            SpinnerHide();
            alert("error " + action + " post");
        }
    })
    .fail(function (jqXHR, textStatus) {
        SpinnerHide();
        alert(action + "Request failed: " + textStatus);
    })
    .always(function () {
    });
}

