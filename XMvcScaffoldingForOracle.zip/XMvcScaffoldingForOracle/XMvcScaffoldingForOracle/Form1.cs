﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using XMvcScaffoldingForOracle.classes;

namespace XMvcScaffoldingForOracle
{
    public partial class Form1 : Form
    {
        public static ProgressBar progressBar = null;
        private static string projectName = "";
        private static string projectPath = "";
        private static DialogResult dialogResult;
        private static string errorMessage = "";
        private const string Model1Edmx_CONSTANT = @"\Models\Model1.edmx";

        public Form1()
        {
            InitializeComponent();
            progressBar1.Visible = false;
            progressBar = progressBar1;
        }

        private void btnSelectProjectFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Visual Studio 2012\Projects";
            openFileDialog1.FileName = "";
            dialogResult = openFileDialog1.ShowDialog();
            if (dialogResult == DialogResult.OK)
                textBox1.Text = openFileDialog1.FileName;
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "")
            {
                dialogResult = MessageBox.Show("Project Name required", "Error", MessageBoxButtons.OK);
                return;
            }

            GetProjectNameAndPath();

            if (!CheckRequirements())
            {
                dialogResult = MessageBox.Show(errorMessage, "Error", MessageBoxButtons.OK);
                return;
            }

            if (XRun.Run(projectPath, projectName))
                dialogResult = MessageBox.Show("Done", "", MessageBoxButtons.OK);
            else
                dialogResult = MessageBox.Show("Error", "Error", MessageBoxButtons.OK);
        }

        /// <summary>
        /// must have Entity Framework Model edmx file
        /// must have Oracle.DataAccess
        /// </summary>
        /// <returns></returns>
        private bool CheckRequirements()
        {
            bool result = true;
            errorMessage = "";

            if (!File.Exists(projectPath + Model1Edmx_CONSTANT)) // edmx file required
                errorMessage = "Model1.edmx required";

            string txt = Utils.ReadTextFile(textBox1.Text);
            if (!txt.Contains(@"<Reference Include=""Oracle.DataAccess, Version=4")) // reference to Oracle.DataAccess version 4 required
                errorMessage = "Oracle.DataAccess Version 4 required";

            if (errorMessage != "") result = false;
            return result;
        }

        private void GetProjectNameAndPath()
        {
            List<string> list = textBox1.Text.Trim().Split('\\').ToList();
            projectName = list.Last().Replace(".csproj", "");
            list.RemoveAt(list.Count() - 1);
            projectPath = string.Join(@"\", list.ToArray());
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnFixEdmxIdentities_Click(object sender, EventArgs e)
        {
            GetProjectNameAndPath();
            if (XRun.FixEdmxIdentities(projectPath))
                dialogResult = MessageBox.Show("Done", "", MessageBoxButtons.OK);
            else
                dialogResult = MessageBox.Show("Error", "Error", MessageBoxButtons.OK);
        }
    }
}
