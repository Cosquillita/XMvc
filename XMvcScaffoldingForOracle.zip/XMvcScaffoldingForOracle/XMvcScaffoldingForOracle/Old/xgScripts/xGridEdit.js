﻿
function EditRecord(tableName, id) {
    SpinnerShow();
    var sURL = "/" + tableName + "/_Edit/" + id;
    $.ajax({
        url: sURL,
        type: "GET"
    })
    .done(function (result) {
        $("#dialogContent").html(result);
        DialogShow();
        InitializeDatePickers();
    })
    .fail(function () {
        alert('fail EditRecord');
    })
    .always(function () {
        SpinnerHide();
    });
}

function EditRecordCancel(event) {
    event.preventDefault();
    DialogHide();
}

function EditRecordConfirm(tableName, id, event) {
    event.preventDefault();
    SpinnerShow();
    var sURL = "/" + tableName + "/_Edit";
    var vars = $('#_editForm').serialize();
    $.ajax({
        url: sURL,
        type: "POST",
        data: vars,
        dataType: "json"
    })
    .done(function (result) {
        if (result.success === "true") {
            var filters = GatherFilters(tableName);
            var sorts = GatherSorts(tableName);
            SpinnerHide();
            DialogHide();
            FilterSortPage(tableName, 0, filters, sorts, id);
        }
        else {
            SpinnerHide();
            alert("error EditRecordConfirm");
        }
    })
    .fail(function () {
        SpinnerHide();
        alert('fail EditRecordConfirm');
    })
    .always(function () {
    });
}

