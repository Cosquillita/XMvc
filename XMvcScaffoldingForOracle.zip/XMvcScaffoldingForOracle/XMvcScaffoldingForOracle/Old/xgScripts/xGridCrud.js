﻿function CrudGet(action, tableName, id) {
    SpinnerShow();
    var sURL = "/" + tableName + "/" + action + "/" + id;
    $.ajax({
        url: sURL,
        type: "GET"
    })
    .done(function (result) {
        $("#dialogContent").html(result);
        DialogShow();
        // InitializeDatePickers();
    })
    .fail(function (jqXHR, textStatus) {
        alert(action + "Request failed: " + textStatus);
    })
    .always(function () {
        SpinnerHide();
    });
}

function CrudCancel(event) {
    event.preventDefault(); // need this because buttons firing twice
    DialogHide();
}

function CrudPost(action, tableName, id /* for Insert, the id will be null */, event) {
    event.preventDefault(); // need this because buttons firing twice
    SpinnerShow();
    var sURL = "/" + tableName + "/" + action + "/";
    var vars = $("form").serialize();

    $.ajax({
        url: sURL,
        type: "POST",
        data: vars
    })
    .done(function (result) {
        if (result.success === "true") {
            // to do : handle id of newly inserted record
            //var filters = GatherFilters(tableName);
            //var sorts = GatherSorts(tableName);
            SpinnerHide();
            DialogHide();
            //FilterSortPage(tableName, 0, filters, sorts, id);
        } else {
            SpinnerHide();
            alert("error " + action + " post");
        }
    })
    .fail(function (jqXHR, textStatus) {
        SpinnerHide();
        alert(action + "Request failed: " + textStatus);
    })
    .always(function () {
    });
}

