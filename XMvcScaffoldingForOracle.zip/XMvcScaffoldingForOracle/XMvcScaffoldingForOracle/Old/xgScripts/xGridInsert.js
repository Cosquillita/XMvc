﻿
function InsertRecord(tableName) {
    SpinnerShow();
    var sURL = "/" + tableName + "/_Create/";
    $.ajax({
        url: sURL,
        type: "GET"
    })
    .done(function (result) {
        $("#dialogContent").html(result);
        DialogShow();
        InitializeDatePickers();
    })
    .fail(function () {
        alert('fail InsertRecord');
    })
    .always(function () {
        SpinnerHide();
    });
}

function InsertRecordCancel(event) {
    event.preventDefault();
    DialogHide();
}

function InsertRecordConfirm(tableName, event) {
    event.preventDefault();
    SpinnerShow();
    var sURL = "/" + tableName + "/_Create/";
    var data = $('#_insertForm').serialize();
    $.ajax({
        url: sURL,
        type: "POST",
        data: data
    })
    .done(function (result) {
        if (result.id) {
            var filters = GatherFilters(tableName);
            var sorts = GatherSorts(tableName);
            SpinnerHide();
            DialogHide();
            FilterSortPage(tableName, 0, filters, sorts, result.id);
        } else {
            SpinnerHide();
            alert("error InsertRecordConfirm");
        }
    })
    .fail(function () {
        SpinnerHide();
        alert('fail InsertRecordConfirm');
    })
    .always(function () {
    });
}

