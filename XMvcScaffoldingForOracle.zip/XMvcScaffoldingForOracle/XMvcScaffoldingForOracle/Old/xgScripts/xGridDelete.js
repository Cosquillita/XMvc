﻿
function DeleteRecord(tableName, id, pageNum) {
    /// the page number is needed to refresh the page once the record is removed.
    SpinnerShow();
    var sURL = "/" + tableName + "/_Delete/" + id;
    var vars = { "id": id, "pageNum": pageNum };
    $.ajax({
        url: sURL,
        type: "GET",
        data: vars
    })
    .done(function (result) {
        $("#dialogContent").html(result);
        DialogShow();
    })
    .fail(function () {
        alert('fail DeleteRecord');
    })
    .always(function () {
        SpinnerHide();
    });
}

function DeleteRecordCancel(event) {
    event.preventDefault();
    DialogHide();
}

function DeleteRecordConfirm(tableName, id, pageNum, event) {
    /// the page number is needed to refresh the page once the record is removed.
    event.preventDefault();
    SpinnerShow();
    var sURL = "/" + tableName + "/_DeleteConfirmed";
    var vars = $('#_deleteForm').serialize();
    $.ajax({
        url: sURL,
        type: "POST",
        data: vars
    })
    .done(function (result) {
        if (result.success === "true") {
            var filters = GatherFilters(tableName);
            var sorts = GatherSorts(tableName);
            SpinnerHide();
            DialogHide();
            FilterSortPage(tableName, pageNum, filters, sorts);
        }
        else {
            SpinnerHide();
            alert("error DeleteRecordConfirm");
        }
    })
    .fail(function () {
        SpinnerHide();
        alert('fail DeleteRecordConfirm');
    })
    .always(function () {
    });
}

