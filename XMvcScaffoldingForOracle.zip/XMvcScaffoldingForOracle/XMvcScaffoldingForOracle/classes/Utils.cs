﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace XMvcScaffoldingForOracle.classes
{
    static class Utils
    {
        private const string rootnamespace_CONSTANT = @"$rootnamespace$";
        private const string compileInclude_CONSTANT = @"    <Compile Include=""{0}"" />";
        private const string contentInclude_CONSTANT = @"    <Content Include=""{0}"" />";

        public static string ReadTextFile(string fileName)
        {
            string result = "";
            using (System.IO.StreamReader sr = new System.IO.StreamReader(fileName))
                result = sr.ReadToEnd();
            return result;
        }

        public static bool DeleteFile(string fileName)
        {
            bool result = false;
            try
            {
                if (System.IO.File.Exists(fileName))
                    System.IO.File.Delete(fileName);
                if (!System.IO.File.Exists(fileName))
                    result = true;
            }
            catch { }
            return result;
        }

        public static bool WriteTextFile(string fileName, string fileContent)
        {
            bool result = false;
            try
            {
                using (System.IO.StreamWriter outfile = new System.IO.StreamWriter(fileName))
                    outfile.Write(fileContent);
                result = true;
            }
            catch { }
            return result;
        }

        public static bool WriteTextFileFromList(string fileName, List<string> lines)
        {
            bool result = false;
            try
            {
                using (System.IO.StreamWriter outfile = new System.IO.StreamWriter(fileName))
                    foreach (string s in lines)
                        outfile.WriteLine(s);
                result = true;
            }
            catch { }
            return result;
        }

        public static void CopyDirectoryAndFiles(string sourcePath, string destinationPath, string folder, string projectName, ref List<string> NewProjectItems)
        {
            string[] files = System.IO.Directory.GetFiles(sourcePath);

            if (!System.IO.Directory.Exists(destinationPath + @"\" + folder))
                System.IO.Directory.CreateDirectory(destinationPath + @"\" + folder);

            foreach (string s in files) // Copy the files and overwrite destination files if they already exist. 
            {
                string fileName = System.IO.Path.GetFileName(s); // Use static Path methods to extract only the file name from the path.
                if (fileName.EndsWith(".pp"))
                {
                    // handle *.pp files which are *.cs files
                    string destinationFile = System.IO.Path.Combine(destinationPath + @"\" + folder, fileName.Replace(".pp", ""));
                    string txt = ReadTextFile(s);
                    txt = txt.Replace(rootnamespace_CONSTANT, projectName);
                    WriteTextFile(destinationFile, txt);
                    NewProjectItems.Add(string.Format(compileInclude_CONSTANT, folder + @"\" + fileName.Replace(".pp", "")));
                }
                else if (fileName.EndsWith(".cshtml"))
                {
                    // handle *.cshtml files
                    string destinationFile = System.IO.Path.Combine(destinationPath + @"\" + folder, fileName);
                    string txt = ReadTextFile(s);
                    txt = txt.Replace(rootnamespace_CONSTANT, projectName);
                    WriteTextFile(destinationFile, txt);
                    NewProjectItems.Add(string.Format(contentInclude_CONSTANT, folder + @"\" + fileName));
                }
                else if (fileName.EndsWith(".css") || fileName.EndsWith(".js"))
                {
                    // handle *.css and *.js files
                    string destinationFile = System.IO.Path.Combine(destinationPath + @"\" + folder, fileName);
                    string txt = ReadTextFile(s);
                    WriteTextFile(destinationFile, txt);
                    NewProjectItems.Add(string.Format(contentInclude_CONSTANT, folder + @"\" + fileName));
                }
                else
                {
                    // handle binary image files
                    string destinationFile = System.IO.Path.Combine(destinationPath + @"\" + folder, fileName);
                    File.Copy(s, destinationFile, true);
                    NewProjectItems.Add(string.Format(contentInclude_CONSTANT, folder + @"\" + fileName));
                }
            }
        }

        public static void CopyBinaryFile(string sourcePathFileName, string targetPathFileName, ref List<string> NewProjectItems)
        {
            File.Copy(sourcePathFileName, targetPathFileName);
            NewProjectItems.Add(string.Format(contentInclude_CONSTANT, targetPathFileName));
        }

        public static void CopyFile(string sourcePathFileName, string targetPathFileName, string projectName, ref List<string> NewProjectItems)
        {
            string txt = ReadTextFile(sourcePathFileName);
            txt = txt.Replace(rootnamespace_CONSTANT, projectName);
            WriteTextFile(targetPathFileName, txt);
            NewProjectItems.Add(string.Format(compileInclude_CONSTANT, targetPathFileName));
        }

        public static int GetIndexOf(List<string> list, string s)
        {
            int result = -1;
            for (int i = 0; i < list.Count(); i++)
            {
                if (list[i].Contains(s))
                {
                    result = i;
                    break;
                }
            }
            return result;
        }
    }
}
