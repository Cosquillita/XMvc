﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Linq.Expressions;
using System.ComponentModel;
using System.Data;
using System.Xml.Linq;
using System.Xml;
using System.Windows.Forms;

namespace XMvcScaffoldingForOracle.classes
{
    static class XRun
    {
        public static string projectPath = "";
        public static string projectName = "";
        public static List<string> NewProjectItems = new List<string>();

        private const string Property_CONSTANT = @"Property";
        private const string Type_CONSTANT = @"Type";
        private const string PropertyRef_CONSTANT = @"PropertyRef";
        private const string Key_CONSTANT = @"Key";
        private const string EntityType_CONSTANT = @"EntityType";
        private const string Model1Edmx_CONSTANT = @"\Models\Model1.edmx";
        private const string StoreGeneratedPattern_CONSTANT = "StoreGeneratedPattern";
        private const string Identity_CONSTANT = "Identity";

        public static bool Run(
            string sProjectPath, 
            string sProjectName)
        {
            bool result = true; projectPath = sProjectPath; projectName = sProjectName; NewProjectItems = new List<string>();

            if (!FixEdmxIdentities(projectPath)) return false;
            if (!FixCsProjFileOracleReferences()) return false;
            if (!AddItemsToProjectOutputFolder()) return false;
            XScaffolder.ScaffoldControllersAndViews(projectPath, projectName, ref NewProjectItems);
            if (!AddMenuItemsToLayoutRazorFile()) return false;
            if (!AddItemsToCsProjFile()) return false;
            
            return result;
        }

        /// <summary>
        /// fix edmx file... storage and conceptual models
        /// make sure all keys have attribute of StoreGeneratedPattern=Identity
        /// </summary>
        /// <returns></returns>
        public static bool FixEdmxIdentities(string sProjectPath)
        {
            // to do : check what happens when key is multi-column.
            // looks like only the first field is being assigned the Identity attribute.
            bool result = false;

            if (!System.IO.File.Exists(sProjectPath + Model1Edmx_CONSTANT)) return result;

            // load xml file
            XElement xfile = XElement.Load(sProjectPath + Model1Edmx_CONSTANT);
            XElement edmxRuntime = xfile.Elements().First();

            // fix storage models
            XElement edmxStorageModels = edmxRuntime.Elements().First();
            edmxStorageModels = edmxStorageModels.Elements().First();
            IEnumerable<XElement> items = edmxStorageModels.Elements().Where(m => m.Name.LocalName == EntityType_CONSTANT);
            foreach (var item in items)
            {
                string keyName = (item.Elements().Where(m => m.Name.LocalName == Key_CONSTANT).First().Elements().Where(m => m.Name.LocalName == PropertyRef_CONSTANT).First()).FirstAttribute.Value.ToString();
                XElement keyElement = item.Elements().Where(m => m.Name.LocalName == Property_CONSTANT).Where(m => m.FirstAttribute.Value.ToString() == keyName).First();
                if (keyElement.Attribute((XName)StoreGeneratedPattern_CONSTANT) == null)
                    keyElement.Add(new XAttribute(StoreGeneratedPattern_CONSTANT, Identity_CONSTANT));
            }

            // fix conceptual models
            XElement edmxConceptualModels = edmxRuntime.Elements().ElementAtOrDefault(1);
            edmxConceptualModels = edmxConceptualModels.Elements().First();
            items = edmxConceptualModels.Elements().Where(m => m.Name.LocalName == EntityType_CONSTANT);
            foreach (var item in items)
            {
                string keyName = (item.Elements().Where(m => m.Name.LocalName == Key_CONSTANT).First().Elements().Where(m => m.Name.LocalName == PropertyRef_CONSTANT).First()).FirstAttribute.Value.ToString();
                try
                {
                    XElement keyElement = item.Elements().Where(m => m.Name.LocalName == Property_CONSTANT).Where(m => m.FirstAttribute.Value.ToString() == keyName).First();
                    if (keyElement.Attributes().Where(m => m.Name.LocalName == StoreGeneratedPattern_CONSTANT).Count() == 0)
                    {
                        XNamespace annotation = "http://schemas.microsoft.com/ado/2009/02/edm/annotation";
                        XAttribute xAttrStoreGen = new XAttribute(annotation + StoreGeneratedPattern_CONSTANT, Identity_CONSTANT);
                        keyElement.Add(xAttrStoreGen);
                    }
                }
                catch { }
            }

            try
            {
                xfile.Save(sProjectPath + Model1Edmx_CONSTANT);
                result = true;
            }
            catch { }
            return result;
        }

        /// <summary>
        /// The *.csproj file for Oracle has incorrect attribute... processorArchitecture=x86.
        /// This corrects it to... processorArchitecture=MSIL.
        /// Also, adds the property ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch=None to prevent compiler warning.
        /// </summary>
        /// <returns></returns>
        private static bool FixCsProjFileOracleReferences()
        {
            bool result = false;
            
            const string OracleDataAccessX86_CONSTANT = @"<Reference Include=""Oracle.DataAccess, Version=4.112.3.0, Culture=neutral, PublicKeyToken=89b483f429c47342, processorArchitecture=x86"">";
            const string OracleDataAccessMSIL_CONSTANT = @"<Reference Include=""Oracle.DataAccess, Version=4.112.3.0, Culture=neutral, PublicKeyToken=89b483f429c47342, processorArchitecture=MSIL"">";
            const string OracleWebX86_CONSTANT = @"<Reference Include=""Oracle.Web, Version=4.112.3.0, Culture=neutral, PublicKeyToken=89b483f429c47342, processorArchitecture=x86"">";
            const string OracleWebMSIL_CONSTANT = @"<Reference Include=""Oracle.Web, Version=4.112.3.0, Culture=neutral, PublicKeyToken=89b483f429c47342, processorArchitecture=MSIL"">";
            const string ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch_CONSTANT = @"<ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch>";
            try
            {
                // read csproj into list
                string txt = Utils.ReadTextFile(projectPath + @"\" + projectName + ".csproj");
                List<string> list = txt.Split('\n').ToList();
                list = list.Select(x => x.Replace('\r', ' ')).ToList(); // strip out carriage returns
                int n = -1;

                if (list.Where(m => m.Contains(OracleDataAccessX86_CONSTANT)).Count() == 1 && list.Where(m => m.Contains(OracleDataAccessMSIL_CONSTANT)).Count() == 0)
                {
                    // fix oracle data access references, if neccessary
                    list = list.Select(x => x.Replace(OracleDataAccessX86_CONSTANT, OracleDataAccessMSIL_CONSTANT)).ToList();
                    n = list.FindIndex(x => x.Contains(OracleDataAccessMSIL_CONSTANT)) + 1;
                    AddCopyLocalFalse(ref list, n);
                }

                if (list.Where(m => m.Contains(OracleWebX86_CONSTANT)).Count() == 1 && list.Where(m => m.Contains(OracleWebMSIL_CONSTANT)).Count() == 0)
                {
                    // fix oracle web references, if neccessary
                    list = list.Select(x => x.Replace(OracleWebX86_CONSTANT, OracleWebMSIL_CONSTANT)).ToList();
                    n = list.FindIndex(x => x.Contains(OracleWebMSIL_CONSTANT)) + 1;
                    AddCopyLocalFalse(ref list, n);
                }

                n = list.FindIndex(x => x.Contains(ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch_CONSTANT));
                if (n == -1)
                {
                    // add ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch reference, if neccessary
                    n = list.FindIndex(x => x.Contains("</PropertyGroup>"));
                    list.Insert(n + 1, "  <PropertyGroup>");
                    list.Insert(n + 2, "    <ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch>");
                    list.Insert(n + 3, "      None");
                    list.Insert(n + 4, "    </ResolveAssemblyWarnOrErrorOnTargetArchitectureMismatch>");
                    list.Insert(n + 5, "  </PropertyGroup>");
                }

                // write fixed csproj
                txt = string.Join(Environment.NewLine, list.ToArray());
                Utils.WriteTextFile(projectPath + @"\" + projectName + ".csproj", txt);
                result = true;
            }
            catch { }
            return result;
        }

        /// <summary>
        /// adds or updates the following items:
        ///     /App_Start/BundleConfig.cs
        ///         new css and javascript references added
        ///     /Content/Site.css
        ///     /Content/xgContent/xGridVanilla.css
        ///         css for xGrid, etc.
        ///     /Controllers/NoCacheAttribute.cs
        ///         attribute for not caching
        ///     /Helpers/HelperExtensions.cs
        ///         razor helpers
        ///     /Images/xgImages/*.*
        ///         various images for xGrid, etc.
        ///     /Models/
        ///         FilterObject.cs
        ///             simple class used in LinqFilter and ModelExtensions
        ///         LinqFilter.cs
        ///             generic filtering for entities
        ///         LinqSorter.cs
        ///             generic sorting for entities
        ///         ModelExtensions.cs
        ///             basic utilities for xGrid, etc.
        ///         SortObject.cs
        ///             simple class used in LinqSorter and ModelExtensions
        ///     /Scripts/xgScripts/
        ///         xGridBasic.js
        ///             generic javascript functions for xGrid, etc.
        ///         xGridCrud.js
        ///             add, update, delete ajax calls
        ///         xGridFilter.js
        ///             filtering javascript
        ///         xGridSort.js
        ///             sorting javascript
        ///     /Views/Home/Index.cshtml
        ///     /Views/Shared/_Layout.cshtml
        /// </summary>
        /// <returns></returns>
        private static bool AddItemsToProjectOutputFolder()
        {
            bool result = false;
            try
            {
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\App_Start", projectPath, @"App_Start", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Content", projectPath, @"Content", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Content\xgContent", projectPath, @"Content\xgContent", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Helpers", projectPath, @"Helpers", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Images\xgImages", projectPath, @"Images\xgImages", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Models", projectPath, @"Models", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Scripts\xgScripts", projectPath, @"Scripts\xgScripts", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Views\Home", projectPath, @"Views\Home", projectName, ref NewProjectItems);
                Utils.CopyDirectoryAndFiles(Application.StartupPath + @"\FoldersAndContent\Views\Shared", projectPath, @"Views\Shared", projectName, ref NewProjectItems);
                Utils.CopyFile(Application.StartupPath + @"\FoldersAndContent\Controllers\NoCacheAttribute.cs.pp", projectPath + @"\Controllers\NoCacheAttribute.cs", projectName, ref NewProjectItems);
                result = true;
            }
            catch { }
            return result;
        }

        /// <summary>
        /// Adds all tables to menu in /Views/Shared/_Layout.cshtml.
        /// </summary>
        /// <returns></returns>
        private static bool AddMenuItemsToLayoutRazorFile()
        {
            bool result = false;
            const string CompileIncludeControllers_CONSTANT = @"<Compile Include=""Controllers\";
            const string _Layout_CONSTANT = @"\Views\Shared\_Layout.cshtml";

            try
            {
                string layoutFileText = Utils.ReadTextFile(projectPath + _Layout_CONSTANT);
                List<string> menuItems = new List<string>();
                foreach (string s in NewProjectItems.Where(m => m.Contains(CompileIncludeControllers_CONSTANT)))
                {
                    string modelName = s.Replace(CompileIncludeControllers_CONSTANT, "").Replace(@"Controller.cs"" />", "").Trim();
                    menuItems.Add(string.Format(@"                    <li>@Html.ActionLink(""{0}"", ""Index"", ""{0}"")</li>", modelName));
                }
                if (!layoutFileText.Contains(menuItems[0].Trim()))
                {
                    // if layout file already has the first item in the list, skip adding anything.
                    menuItems.Sort();
                    layoutFileText = layoutFileText.Replace(@"                    $menuItems$", string.Join(Environment.NewLine, menuItems.ToArray()));
                    Utils.WriteTextFile(projectPath + _Layout_CONSTANT, layoutFileText);
                }
                result = true;
            }
            catch { }
            return result;
        }

        /// <summary>
        /// Adds new entity classes to *.csproj file.
        /// </summary>
        /// <returns></returns>
        private static bool AddItemsToCsProjFile()
        {
            bool result = true;
            const string CompileInclude_CONSTANT = @"<Compile Include=";
            const string ContentInclude_CONSTANT = @"<Content Include=";

            // read csproj into list
            string txt = Utils.ReadTextFile(projectPath + @"\" + projectName + ".csproj");
            List<string> list = txt.Split('\n').ToList();
            list = list.Select(x => x.Replace('\r', ' ')).ToList(); // strip out carriage returns
            int n = -1;
            
            // add all new items to csproj if they don't already exist.
            foreach (string s in NewProjectItems)
            {
                n = list.FindIndex(x => x.Contains(s.Trim()));
                if (n == -1)
                {
                    if (s.Trim().StartsWith(CompileInclude_CONSTANT))
                    {
                        n = list.FindIndex(x => x.Contains(CompileInclude_CONSTANT));
                        list.Insert(n, s);
                    }
                    else
                    {
                        n = list.FindIndex(x => x.Contains(ContentInclude_CONSTANT));
                        list.Insert(n, s);
                    }
                }
            }

            // write fixed csproj
            txt = string.Join(Environment.NewLine, list.ToArray());
            Utils.WriteTextFile(projectPath + @"\" + projectName + ".csproj", txt);

            return result;
        }

        /// <summary>
        /// Add copy local = false attribute (aka Private=False) to reference if not exists already.
        /// This prevents the Oracle dll's from being copied to the bin folder which creates an error on the web server.
        /// </summary>
        /// <param name="list"></param>
        /// <param name="n"></param>
        public static void AddCopyLocalFalse(ref List<string> list, int n)
        {
            string copyLocalFalse = @"      <Private>False</Private>";
            bool foundCopyLocalRef = false;
            for (int i = n; i < list.Count; i++)
            {
                if (list[i].Trim() == @"</Reference>")
                    break;
                if (list[i].Trim().StartsWith(@"<Private>"))
                {
                    foundCopyLocalRef = true;
                    list[i] = copyLocalFalse;
                    break;
                }
            }
            if (!foundCopyLocalRef)
                list.Insert(n, copyLocalFalse);
        }
    }
}
