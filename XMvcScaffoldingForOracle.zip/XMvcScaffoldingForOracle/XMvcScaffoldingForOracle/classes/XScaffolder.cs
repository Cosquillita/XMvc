﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Linq.Expressions;
using System.ComponentModel;
using System.Data;
using System.Xml.Linq;
using System.Xml;
using System.Windows.Forms;

namespace XMvcScaffoldingForOracle.classes
{
    public enum RelationshipType { none, child, parent, sibling };
    public enum MultiplicityType // descriptions match up to those in the edmx file
    {
        [Description(" ")]
        none,
        [Description("1")]
        one,
        [Description("*")]
        many,
        [Description("0..*")]
        zeroOrMany,
        [Description("0..1")]
        zeroOrOne
    }
    public class RelatedEntity
    {
        public MultiplicityType tableMultiplicity = MultiplicityType.none;
        public string tableName = "";
        public string columnName = "";
        public RelationshipType relatedTableType = RelationshipType.none;
        public MultiplicityType relatedTableMultiplicity = MultiplicityType.none;
        public string relatedTableName = "";
        public string relatedColumnName = "";
        public string relatedDisplayColumnName = "";
    }

    /// <summary>
    /// uses xml linq to read edmx file and create controllers and views
    /// </summary>
    static class XScaffolder
    {
        private const string columnName_CONSTANT = @"$columnName$";
        private const string relatedTableName_CONSTANT = @"$relatedTableName$";
        private const string relatedColumnName_CONSTANT = @"$relatedColumnName$";
        private const string modelName_CONSTANT = @"$modelName$";
        private const string modelVariable_CONSTANT = @"$modelVariable$";
        private const string primaryKeyName_CONSTANT = @"$primaryKeyName$";
        private const string rootnamespace_CONSTANT = @"$rootnamespace$";
        private const string relatedDisplayColumnName_CONSTANT = @"$relatedDisplayColumnName$";
        private const string primaryKeyType_CONSTANT = @"$primaryKeyType$";
        private const string projectName_CONSTANT = @"$projectName$";
        private const string clearFloat_CONSTANT = @"<div class=""clearFloat""></div>";
        private const string DateTime_CONSTANT = @"DateTime";
        private const string Property_CONSTANT = @"Property";
        private const string Type_CONSTANT = @"Type";
        private const string PropertyRef_CONSTANT = @"PropertyRef";
        private const string Key_CONSTANT = @"Key";
        private const string EntityType_CONSTANT = @"EntityType";
        private const string Model1Edmx_CONSTANT = @"\Models\Model1.edmx";

        private static string projectPath = "";
        private static string projectName = "";
        private static List<string> NewProjectItems = new List<string>();
        private static XElement edmxConceptualSchema = null;
        private static Dictionary<string, MultiplicityType> dictMultiplicities = new Dictionary<string, MultiplicityType>() { { MultiplicityType.none.ToString(), MultiplicityType.none }, { MultiplicityType.one.ToString(), MultiplicityType.one }, { MultiplicityType.many.ToString(), MultiplicityType.many }, { MultiplicityType.zeroOrMany.ToString(), MultiplicityType.zeroOrMany }, { MultiplicityType.zeroOrOne.ToString(), MultiplicityType.zeroOrOne } };

        /// <summary>
        /// read thru the conceptual models part of the edmx file and create the controllers and views.
        /// </summary>
        /// <param name="sProjectPath"></param>
        /// <param name="sProjectName"></param>
        /// <param name="listProjectItems"></param>
        public static void ScaffoldControllersAndViews(
            string sProjectPath, 
            string sProjectName, 
            ref List<string> listProjectItems)
        {
            projectPath = sProjectPath; projectName = sProjectName; NewProjectItems = listProjectItems;
            string edmxFileName = projectPath + Model1Edmx_CONSTANT;
            XElement xfile = XElement.Load(edmxFileName);
            XElement edmxRuntime = xfile.Elements().First();
            XElement edmxConceptualModels = edmxRuntime.Elements().Where(m => m.Name.LocalName == "ConceptualModels").First();
            edmxConceptualSchema = edmxConceptualModels.Elements().First();
            IEnumerable<XElement> items = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == EntityType_CONSTANT);
            Form1.progressBar.Visible = true;
            Form1.progressBar.Minimum = 1;
            Form1.progressBar.Maximum = items.Count();
            Form1.progressBar.Value = 1;
            Form1.progressBar.Step = 1;
            foreach (var item in items)
            {
                CreateControllerAndViews(item);
                Form1.progressBar.PerformStep();
            }
            Form1.progressBar.Visible = false;
            listProjectItems = NewProjectItems;
        }

        /// <summary>
        /// 1. setup
        /// 2. get related entities
        /// 3. add select lists (aka lookups, dropdowns)
        /// 4. replace vars
        /// 5. fix for caret
        /// 6. save controller to file and add to list of new items
        /// 7. add views
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private static bool CreateControllerAndViews(XElement item)
        {
            bool result = true;

            // setup
            string controller = Utils.ReadTextFile(Application.StartupPath + @"\Scaffolders\Controllers\Controller.cs.pp");
            string modelName = ""; string modelVariable = ""; string primaryKeyName = ""; string primaryKeyType = "";
            SetUpControllerVariables(item, ref modelName, ref modelVariable, ref primaryKeyName, ref primaryKeyType);
            IEnumerable<XElement> columns = item.Elements();
            if (modelVariable == "event") modelVariable = "eventt"; // fix for event which is a reserved word in C#

            // GetRelatedEntities
            Dictionary<string, RelatedEntity> relatedEntities = GetRelatedEntities(modelName);
            Dictionary<string, RelatedEntity> parents = GetRelatedEntitiesByType(RelationshipType.parent, relatedEntities);
            Dictionary<string, RelatedEntity> children = GetRelatedEntitiesByType(RelationshipType.child, relatedEntities);
            Dictionary<string, RelatedEntity> siblings = GetRelatedEntitiesByType(RelationshipType.sibling, relatedEntities);

            controller = AddParentSiblingIncludes(modelName, controller, relatedEntities);

            // add in select lists for _Create, _Edit, _Delete, _Details, _CreateOrEdit actions
            Dictionary<string, string> selectListsForViewsDict = new Dictionary<string, string>();
            controller = AddSelectListsToController(modelName, controller, parents, ref selectListsForViewsDict);

            // replace vars not already replaced
            controller = controller.Replace(modelName_CONSTANT, modelName);
            controller = controller.Replace(modelVariable_CONSTANT, modelVariable);
            controller = controller.Replace(primaryKeyName_CONSTANT, primaryKeyName);
            controller = controller.Replace(primaryKeyType_CONSTANT, primaryKeyType);
            controller = controller.Replace(rootnamespace_CONSTANT, projectName);
            controller = controller.Replace(projectName_CONSTANT, projectName);

            // fix for caret... since I use caret for replacements, defaultSorts in template use %, change that back to a caret for the program logic
            controller = controller.Replace("%1", "^1");

            // save controller to file
            Utils.WriteTextFile(projectPath + @"\Controllers\" + modelName + "Controller.cs", controller);

            // add Controller to list of new items
            NewProjectItems.Add(string.Format(@"    <Compile Include=""Controllers\{0}Controller.cs"" />", modelName));

            CreateViews(modelName, item, modelVariable, primaryKeyName, columns, parents, children, siblings, selectListsForViewsDict);

            return result;
        }

        private static void CreateViews(
            string modelName,
            XElement entityModel,
            string modelVariable,
            string primaryKeyName,
            IEnumerable<XElement> columns,
            Dictionary<string, RelatedEntity> parents,
            Dictionary<string, RelatedEntity> children,
            Dictionary<string, RelatedEntity> siblings,
            Dictionary<string, string> selectListsForViewsDict
            )
        {
            string viewOutputFolder = projectPath + @"\Views\" + modelName;
            if (System.IO.Directory.Exists(viewOutputFolder)) System.IO.Directory.Delete(viewOutputFolder, true);
            System.IO.Directory.CreateDirectory(viewOutputFolder);
            string templateFolder = Application.StartupPath + @"\Scaffolders\Views\";
            List<string> views = new List<string>() { "_Create.cshtml", "_CreateOrEdit.cshtml", "_Delete.cshtml", "_Details.cshtml", "_Edit.cshtml", "_Index.cshtml", "Index.cshtml" };
            foreach (string cshtmlFile in views)
            {
                string view = Utils.ReadTextFile(templateFolder + cshtmlFile);
                switch (cshtmlFile)
                {
                    case "_Index.cshtml":
                        view = CreateView_Index(view, modelName, entityModel, modelVariable, primaryKeyName, columns, parents, children, siblings, selectListsForViewsDict);
                        break;
                    case "_CreateOrEdit.cshtml":
                        view = CreateView_CreateOrEdit(view, modelName, entityModel, modelVariable, primaryKeyName, columns, parents, children, siblings, selectListsForViewsDict);
                        break;
                    case "_Details.cshtml":
                        view = CreateView_Details(view, modelName, entityModel, modelVariable, primaryKeyName, columns, parents, children, siblings, selectListsForViewsDict);
                        break;
                    default:
                        view = view.Replace(rootnamespace_CONSTANT, projectName).Replace(modelName_CONSTANT, modelName).Replace(primaryKeyName_CONSTANT, primaryKeyName);
                        break;
                }
                Utils.WriteTextFile(viewOutputFolder + @"\" + cshtmlFile, view);
                NewProjectItems.Add(string.Format(@"    <Content Include=""Views\{0}\{1}"" />", modelName, cshtmlFile));
            }
        }

        /// <summary>
        /// assign modelName, modelVariable, primaryKeyName, primaryKeyType
        /// </summary>
        /// <param name="item"></param>
        /// <param name="modelName"></param>
        /// <param name="modelVariable"></param>
        /// <param name="primaryKeyName"></param>
        /// <param name="primaryKeyType"></param>
        private static void SetUpControllerVariables(XElement item, ref string modelName, ref string modelVariable, ref string primaryKeyName, ref string primaryKeyType)
        {
            modelName = item.FirstAttribute.Value; modelVariable = modelName.ToLower(); primaryKeyType = "";
            primaryKeyName = item.Elements().Where(m => m.Name.LocalName == Key_CONSTANT).First().Elements().Where(m => m.Name.LocalName == PropertyRef_CONSTANT).First().FirstAttribute.Value;
            foreach (XElement xe in item.Elements().Where(m => m.Name.LocalName == Property_CONSTANT)) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value == primaryKeyName)
                {
                    primaryKeyType = xe.Attribute(Type_CONSTANT).Value.StartsWith("Int") ? "int" : "string";
                    break;
                }
            }
        }

        /// <summary>
        /// get parents, siblings and children
        /// </summary>
        /// <param name="modelName"></param>
        /// <returns></returns>
        private static Dictionary<string, RelatedEntity> GetRelatedEntities(string modelName)
        {
            const string FromRole_CONSTANT = @"FromRole";
            const string ToRole_CONSTANT = @"ToRole";
            const string Role_CONSTANT = @"Role";
            const string End_CONSTANT = @"End";
            const string Multiplicity_CONSTANT = @"Multiplicity";

            // get parents, siblings, children
            Dictionary<string, MultiplicityType> dictMultiplicities = new Dictionary<string, MultiplicityType>() { { " ", MultiplicityType.none }, { "1", MultiplicityType.one }, { "*", MultiplicityType.many }, { "0..*", MultiplicityType.zeroOrMany }, { "0..1", MultiplicityType.zeroOrOne } };

            Dictionary<string, RelatedEntity> result = new Dictionary<string, RelatedEntity>();
            IEnumerable<XElement> modelItems = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == EntityType_CONSTANT && m.Attribute("Name").Value == modelName);
            foreach (var item in modelItems)
            {
                var navProps = item.Elements().Where(m => m.Name.LocalName == "NavigationProperty");
                foreach (var navProp in navProps)
                {
                    string fromRole = navProp.Attributes().Where(n => n.Name.LocalName == FromRole_CONSTANT).First().Value;
                    string toRole = navProp.Attributes().Where(n => n.Name.LocalName == ToRole_CONSTANT).First().Value;
                    string relationship = navProp.Attribute("Relationship").Value.Replace("Model.", "");
                    string navName = navProp.Attribute("Name").Value;
                    if (edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == "Association" && m.Attribute("Name").Value == relationship).Count() > 0)
                    {
                        XElement associationItem = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == "Association" && m.Attribute("Name").Value == relationship).First();
                        XElement modelRole = associationItem.Elements().Where(m => m.Name.LocalName == End_CONSTANT && m.Attribute(Role_CONSTANT).Value == fromRole).First();
                        XElement relatedRole = associationItem.Elements().Where(m => m.Name.LocalName == End_CONSTANT && m.Attribute(Role_CONSTANT).Value == toRole).First();

                        if (modelRole.Attribute("Type").Value == relatedRole.Attribute("Type").Value)
                        {
                            // skip self-references which can cause infinite loop and stack overflow.
                            continue;
                        }

                        XElement referentialConstraint = associationItem.Elements().Where(m => m.Name.LocalName == "ReferentialConstraint").First();
                        XElement referentialPropForModel = referentialConstraint.Elements().Where(m => m.Attribute(Role_CONSTANT).Value == modelName).First();
                        XElement referentialPropForRelated = referentialConstraint.Elements().Where(m => m.Attribute(Role_CONSTANT).Value == toRole).First();

                        string columnName = referentialPropForModel.Elements().First().FirstAttribute.Value;
                        string relatedColumnName = referentialPropForRelated.Elements().First().FirstAttribute.Value;

                        RelatedEntity R = new RelatedEntity();
                        R.tableName = modelName;
                        R.columnName = columnName;
                        R.relatedTableName = toRole;
                        R.relatedColumnName = relatedColumnName;
                        R.tableMultiplicity = dictMultiplicities[modelRole.Attribute(Multiplicity_CONSTANT).Value];
                        R.relatedTableMultiplicity = dictMultiplicities[relatedRole.Attribute(Multiplicity_CONSTANT).Value];
                        // here is where the type is set to parent, sibling or child
                        R.relatedTableType = SetRelatedTableType(R.tableMultiplicity, R.relatedTableMultiplicity, referentialPropForModel, referentialPropForRelated);
                        if (R.relatedTableType == RelationshipType.parent)
                        {
                            // get the display column if the related entity is a parent. if none, leave blank.
                            XElement relatedItem = edmxConceptualSchema.Elements().Where(m => m.Name.LocalName == EntityType_CONSTANT && m.FirstAttribute.Value == toRole).First();
                            IEnumerable<XElement> displayColumns = relatedItem.Elements().Where(m => m.Name.LocalName == Property_CONSTANT && m.FirstAttribute.Value != relatedColumnName);
                            if (displayColumns.Count() >= 1)
                                R.relatedDisplayColumnName = displayColumns.First().FirstAttribute.Value;
                        }
                        result.Add(navName, R);
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// set the related table type to parent, sibling or child
        /// </summary>
        /// <param name="tableMultiplicity"></param>
        /// <param name="relatedTableMultiplicity"></param>
        /// <param name="referentialPropForModel"></param>
        /// <param name="referentialPropForRelated"></param>
        /// <returns></returns>
        private static RelationshipType SetRelatedTableType(
            MultiplicityType tableMultiplicity,
            MultiplicityType relatedTableMultiplicity,
            XElement referentialPropForModel,
            XElement referentialPropForRelated)
        {
            RelationshipType result = RelationshipType.none;
            if ((tableMultiplicity == MultiplicityType.one || tableMultiplicity == MultiplicityType.zeroOrOne) && (relatedTableMultiplicity == MultiplicityType.many || relatedTableMultiplicity == MultiplicityType.zeroOrMany))
                result = RelationshipType.child;
            else if ((tableMultiplicity == MultiplicityType.one || tableMultiplicity == MultiplicityType.zeroOrOne) && (relatedTableMultiplicity == MultiplicityType.one || relatedTableMultiplicity == MultiplicityType.zeroOrOne))
                result = RelationshipType.sibling;
            else if ((relatedTableMultiplicity == MultiplicityType.one || relatedTableMultiplicity == MultiplicityType.zeroOrOne) && (tableMultiplicity == MultiplicityType.many || tableMultiplicity == MultiplicityType.zeroOrMany))
                result = RelationshipType.parent;
            return result;
        }

        private static Dictionary<string, RelatedEntity> GetRelatedEntitiesByType(RelationshipType relatedTableType, Dictionary<string, RelatedEntity> relatedEntities)
        {
            Dictionary<string, RelatedEntity> result = new Dictionary<string, RelatedEntity>();
            foreach (string key in relatedEntities.Keys)
                if (relatedEntities[key].relatedTableType == relatedTableType)
                    result.Add(key, relatedEntities[key]);
            return result;
        }

        /// <summary>
        /// these are the lazy loading includes for the _Index controller action
        /// </summary>
        /// <param name="modelName"></param>
        /// <param name="controller"></param>
        /// <param name="relatedEntities"></param>
        /// <returns></returns>
        private static string AddParentSiblingIncludes(string modelName, string controller, Dictionary<string, RelatedEntity> relatedEntities)
        {
            string result = controller;
            List<string> parentSiblingIncludes = GetModelIncludes(modelName, relatedEntities);
            string includes = "";
            foreach (string s in parentSiblingIncludes)
                includes += string.Format(@".Include(m => m.{0})", s);
            if (includes == "")
                result = result.Replace(@"			$modelVariable$ = $modelVariable$$parentSiblingTableIncludes$;", "");
            else
            {
                includes = @"			" + modelName.ToLower() + @" = " + modelName.ToLower() + includes + ";";
                result = result.Replace(@"			$modelVariable$ = $modelVariable$$parentSiblingTableIncludes$;", includes);
            }
            return result;
        }

        private static List<string> GetModelIncludes(string modelName, Dictionary<string, RelatedEntity> relatedEntities)
        {
            List<string> result = new List<string>();
            foreach (string key in relatedEntities.Keys)
                if (relatedEntities[key].relatedTableType == RelationshipType.parent || relatedEntities[key].relatedTableType == RelationshipType.sibling)
                    result.Add(key);
            return result;
        }

        private static string AddSelectListsToController(
            string modelName, 
            string controller, 
            Dictionary<string, RelatedEntity> parents, 
            ref Dictionary<string, string> selectListsForViewsDict)
        {
            string result = controller;
            string selectLists = "";
            string selectListsNoSelection = "";
            string selectListsForFilters = "";

            if (parents.Count == 0)
            {
                // if no parents, send back the controller unchanged.
                result = result.Replace("$Repeat-Section-SelectLists$", "");
                result = result.Replace("$Repeat-Section-SelectLists-NoSelection$", "");
                result = result.Replace("$Repeat-Section-SelectListsForViews$", "");
                return result;
            }

            foreach (string key in parents.Keys)
            {
                RelatedEntity R = parents[key];

                selectLists += @"			" +
                    @"ViewBag.$columnName$ = new SelectList(db.$relatedTableName$, ""$relatedColumnName$"", ""$relatedDisplayColumnName$"", $modelVariable$.$columnName$);".
                    Replace(modelVariable_CONSTANT, modelName.ToLower()).
                    Replace(columnName_CONSTANT, R.columnName).
                    Replace(relatedTableName_CONSTANT, R.relatedTableName).
                    Replace(relatedColumnName_CONSTANT, R.relatedColumnName).
                    Replace(relatedDisplayColumnName_CONSTANT, R.relatedDisplayColumnName) +
                    Environment.NewLine;

                selectListsNoSelection += @"			" +
                    @"ViewBag.$columnName$ = new SelectList(db.$relatedTableName$, ""$relatedColumnName$"", ""$relatedDisplayColumnName$"");".
                    Replace(modelVariable_CONSTANT, modelName.ToLower()).
                    Replace(columnName_CONSTANT, R.columnName).
                    Replace(relatedTableName_CONSTANT, R.relatedTableName).
                    Replace(relatedColumnName_CONSTANT, R.relatedColumnName).
                    Replace(relatedDisplayColumnName_CONSTANT, R.relatedDisplayColumnName) +
                    Environment.NewLine;

                const string selectListsForFiltersTemplate =
@"            Dictionary<string, string> dict$columnName$ = db.$relatedTableName$.Select(m => new { m.$relatedColumnName$, m.$relatedDisplayColumnName$ }).OrderBy(m => m.$relatedDisplayColumnName$).ToDictionary(m => m.$relatedColumnName$.ToString(), m => m.$relatedDisplayColumnName$ == null ? """" : m.$relatedDisplayColumnName$.ToString());
            ViewBag.dropdownList$columnName$ = Helpers.HelperExtensions.CreateDropDownList(""$modelName$"", ""$columnName$"", filterz, dict$columnName$);";

                selectListsForFilters += selectListsForFiltersTemplate.
                    Replace(columnName_CONSTANT, R.columnName).
                    Replace(relatedColumnName_CONSTANT, R.relatedColumnName).
                    Replace(relatedDisplayColumnName_CONSTANT, R.relatedDisplayColumnName).
                    Replace(modelName_CONSTANT, modelName).
                    Replace(relatedTableName_CONSTANT, R.relatedTableName) + Environment.NewLine;

                selectListsForViewsDict.Add(R.columnName, ("@ViewBag.dropdownList$columnName$").Replace(columnName_CONSTANT, R.columnName));
            }

            if (selectLists.Length > 0) // remove last CrLf
            {
                selectLists = selectLists.Substring(0, selectLists.Length - 2);
                selectListsNoSelection = selectListsNoSelection.Substring(0, selectListsNoSelection.Length - 2);
            }
            if (selectListsForFilters.Length > 0) // remove last CrLf
                selectListsForFilters = selectListsForFilters.Substring(0, selectListsForFilters.Length - 2);

            result = result.Replace(@"			$Repeat-Section-SelectLists-NoSelection$", selectListsNoSelection);
            result = result.Replace(@"				$Repeat-Section-SelectLists$", selectLists);
            result = result.Replace(@"			$Repeat-Section-SelectLists$", selectLists);
            result = result.Replace(@"			$Repeat-Section-SelectListsForViews$", selectListsForFilters);

            return result;
        }

        private static string CreateView_CreateOrEdit(
            string view,
            string modelName,
            XElement entityModel,
            string modelVariable,
            string primaryKeyName,
            IEnumerable<XElement> columns,
            Dictionary<string, RelatedEntity> parents,
            Dictionary<string, RelatedEntity> children,
            Dictionary<string, RelatedEntity> siblings,
            Dictionary<string, string> selectListsForViewsDict)
        {
            string result = "";
            view = view.Replace(rootnamespace_CONSTANT, projectName).Replace(modelName_CONSTANT, modelName);
            string columnStrings = "";

            const string columnTemplateText =
@"<div class=""editorLabel"">@Html.LabelFor(model => model.$columnName$)</div>
<div class=""editorField"">@Html.EditorFor(model => model.$columnName$)@Html.ValidationMessageFor(model => model.$columnName$)</div>";

            const string columnTemplateSelect =
@"<div class=""editorLabel"">@Html.LabelFor(model => model.$columnName$, ""$relatedTableName$"")</div>
<div class=""editorField"">@Html.DropDownList(""$columnName$"", String.Empty)@Html.ValidationMessageFor(model => model.$columnName$)</div>";

            int r = 0;
            foreach (XElement xe in columns.Where(m => m.Name.LocalName == Property_CONSTANT)) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value == primaryKeyName && xe.Attribute(Type_CONSTANT).Value.StartsWith("Int")) continue; // skip integer primary key column
                string columnName = xe.FirstAttribute.Value;
                string parentTableName = "";
                foreach (string key in parents.Keys)
                {
                    if (parents[key].columnName == columnName)
                    {
                        parentTableName = key;
                        break;
                    }
                }
                if (parentTableName != "")
                {
                    // select/dropdownlist
                    columnStrings += columnTemplateSelect.Replace(columnName_CONSTANT, columnName).Replace(relatedTableName_CONSTANT, parents[parentTableName].relatedTableName) + Environment.NewLine;
                }
                else
                {
                    // text or calendar
                    columnStrings += columnTemplateText.Replace(columnName_CONSTANT, columnName) + Environment.NewLine;
                }

                r += 1;
                if (r % 2 == 0) columnStrings += clearFloat_CONSTANT + Environment.NewLine;
            }
            view = view.Replace("$Repeat-Section$", columnStrings);
            result = view;
            return result;
        }

        private static string CreateView_Details(
            string view,
            string modelName,
            XElement entityModel,
            string modelVariable,
            string primaryKeyName,
            IEnumerable<XElement> columns,
            Dictionary<string, RelatedEntity> parents,
            Dictionary<string, RelatedEntity> children,
            Dictionary<string, RelatedEntity> siblings,
            Dictionary<string, string> selectListsForViewsDict)
        {
            string result = "";
            view = view.Replace(rootnamespace_CONSTANT, projectName).Replace(modelName_CONSTANT, modelName);
            string columnStrings = "";

            const string columnTemplate =
@"<div class=""displayLabel"">@Html.DisplayNameFor(model => model.$columnName$)</div>
<div class=""displayField"">@Html.DisplayFor(model => model.$columnName$)</div>";

            const string columnTemplateParentLookup =
@"<div class=""displayLabel"">@Html.DisplayNameFor(model => model.$relatedTableName$.$relatedDisplayColumnName$)</div>
<div class=""displayField"">@Html.DisplayFor(model => model.$relatedTableName$.$relatedDisplayColumnName$)</div>";

            int r = 0;
            foreach (XElement xe in columns.Where(m => m.Name.LocalName == Property_CONSTANT)) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value == primaryKeyName && xe.Attribute(Type_CONSTANT).Value.StartsWith("Int")) continue; // skip integer primary key column
                string columnName = xe.FirstAttribute.Value;
                if (parents.Keys.Contains(columnName))
                    columnStrings += columnTemplateParentLookup.Replace(columnName_CONSTANT, columnName).Replace(relatedTableName_CONSTANT, parents[columnName].relatedTableName).Replace("$relatedDisplayColumnName$", parents[columnName].relatedDisplayColumnName) + Environment.NewLine;
                else
                    columnStrings += columnTemplate.Replace(columnName_CONSTANT, columnName) + Environment.NewLine;
                r += 1;
                if (r % 2 == 0) columnStrings += clearFloat_CONSTANT + Environment.NewLine;
            }
            view = view.Replace("$Repeat-Section$", columnStrings);
            result = view;
            return result;
        }

        private static string CreateView_Index(
            string view,
            string modelName,
            XElement entityModel,
            string modelVariable,
            string primaryKeyName,
            IEnumerable<XElement> columns,
            Dictionary<string, RelatedEntity> parents,
            Dictionary<string, RelatedEntity> children,
            Dictionary<string, RelatedEntity> siblings,
            Dictionary<string, string> selectListsForViewsDict)
        {
            string result = "";

            const string sortRowRepeatSection = @"		$Repeat-Section-SortRow$";
            const string sortRowItem = @"		<th><a href=""javascript:"" id=""$modelName$_$columnName$_Sort"" class=""spriteSort @HelperExtensions.GetSortDirection(""$columnName$"", ViewBag.dictSortDirections)"" onclick=""SortTable('$modelName$', this);"" data-sort-order=""@HelperExtensions.GetSortOrder(""$columnName$"", ViewBag.dictSortOrders)""><span>$columnName$</span></a></th>";
            const string filterRowRepeatSection = @"		$Repeat-Section-FilterRow$";
            const string filterRowItemText = @"		<th><input name=""$modelName$_$columnName$_Filter"" class=""xgFilterText"" type=""text"" value=""@HelperExtensions.GetFilter(""$columnName$"", ViewBag.dictFilters)"" onkeydown=""FilterTextColumn('$modelName$', this, event);"" /></th>";
            const string filterRowItemSelect = @"		<th>{0}</th>";
            const string filterRowItemDate = @"		<th><input name=""$modelName$_$columnName$_Filter"" class=""xgFilterDate"" type=""text"" value=""@HelperExtensions.GetFilter(""$columnName$"", ViewBag.dictFilters)"" onchange=""FilterColumn('$modelName$', this, event);"" /></th>";
            const string dataRowRepeatSection = @"		$Repeat-Section-DataRow$";
            const string dataRowItem = @"		<td>@item.$columnName$</td>";
            const string dataRowItemDate = @"		<td>@Html.DisplayFor(modelItem => item.$columnName$)</td>";
            const string dataRowItemParent = @"		<td>@Html.DisplayFor(m => item.$relatedTableName$.$relatedDisplayColumnName$)</td>";
            string columnStrings = "";
            int columnCount = 0;

            // create sort column headers ///////////////////////////////////////////////////////////////////////////////////////////////
            foreach (XElement xe in columns.Where(m => m.Name.LocalName == Property_CONSTANT)) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value == primaryKeyName && xe.Attribute(Type_CONSTANT).Value.StartsWith("Int")) continue; // skip integer primary key column
                columnStrings += sortRowItem.Replace(columnName_CONSTANT, xe.FirstAttribute.Value) + Environment.NewLine;
                columnCount += 1;
            }
            view = view.Replace(sortRowRepeatSection, columnStrings);

            // create filter row ////////////////////////////////////////////////////////////////////////////////////////////////////////
            columnStrings = "";
            foreach (XElement xe in columns.Where(m => m.Name.LocalName == Property_CONSTANT)) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value == primaryKeyName && xe.Attribute(Type_CONSTANT).Value.StartsWith("Int")) continue; // skip integer primary key column
                string columnName = xe.FirstAttribute.Value;
                XAttribute xa = xe.Attributes().Where(m => m.Name.LocalName == Type_CONSTANT).First();
                switch (xa.Value)
                {
                    case DateTime_CONSTANT:
                        columnStrings += filterRowItemDate.Replace(columnName_CONSTANT, columnName) + Environment.NewLine;
                        break;
                    default:
                        if (selectListsForViewsDict.Keys.Contains(columnName))
                            columnStrings += string.Format(filterRowItemSelect, selectListsForViewsDict[columnName]) + Environment.NewLine;
                        else
                            columnStrings += filterRowItemText.Replace(columnName_CONSTANT, columnName) + Environment.NewLine;
                        break;
                }
            }
            view = view.Replace(filterRowRepeatSection, columnStrings);

            // create data row //////////////////////////////////////////////////////////////////////////////////////////////////////////
            columnStrings = "";
            foreach (XElement xe in columns.Where(m => m.Name.LocalName == Property_CONSTANT)) // skip key and navigation properties
            {
                if (xe.FirstAttribute.Value == primaryKeyName && xe.Attribute(Type_CONSTANT).Value.StartsWith("Int")) continue; // skip integer primary key column
                string columnName = xe.FirstAttribute.Value;
                XAttribute xa = xe.Attributes().Where(m => m.Name.LocalName == Type_CONSTANT).First();
                switch (xa.Value)
                {
                    case DateTime_CONSTANT:
                        columnStrings += dataRowItemDate.Replace(columnName_CONSTANT, columnName) + Environment.NewLine;
                        break;
                    default:
                        RelatedEntity r = GetRelatedEntityForDisplay(columnName, parents);
                        if (r != null)
                            columnStrings += dataRowItemParent.Replace(relatedTableName_CONSTANT, r.relatedTableName).Replace(relatedDisplayColumnName_CONSTANT, r.relatedDisplayColumnName) + Environment.NewLine;
                        else
                            columnStrings += dataRowItem.Replace(columnName_CONSTANT, columnName) + Environment.NewLine;
                        break;
                }
            }
            view = view.Replace(dataRowRepeatSection, columnStrings).Replace("$columnCount$", (columnCount + 1).ToString()).Replace(rootnamespace_CONSTANT, projectName);
            view = view.Replace(modelName_CONSTANT, modelName).Replace(modelVariable_CONSTANT, modelVariable).Replace(primaryKeyName_CONSTANT, primaryKeyName);

            result = view;
            return result;
        }

        private static RelatedEntity GetRelatedEntityForDisplay(string columnName, Dictionary<string, RelatedEntity> dictRelatedEntities)
        {
            RelatedEntity result = null;
            try
            {
                result = dictRelatedEntities.Where(m => m.Value.columnName == columnName).First().Value;
            }
            catch { }
            return result;
        }
    }
}
