﻿namespace XMvcScaffoldingForOracle
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectProjectFile = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAfterRunningMessage = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.label4 = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.btnFixEdmxIdentities = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Project File (*.csproj)";
            // 
            // btnSelectProjectFile
            // 
            this.btnSelectProjectFile.Location = new System.Drawing.Point(12, 139);
            this.btnSelectProjectFile.Name = "btnSelectProjectFile";
            this.btnSelectProjectFile.Size = new System.Drawing.Size(115, 23);
            this.btnSelectProjectFile.TabIndex = 1;
            this.btnSelectProjectFile.Text = "Select Project File";
            this.btnSelectProjectFile.UseVisualStyleBackColor = true;
            this.btnSelectProjectFile.Click += new System.EventHandler(this.btnSelectProjectFile_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 113);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(311, 20);
            this.textBox1.TabIndex = 2;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(360, 139);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 3;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(263, 39);
            this.label2.TabIndex = 4;
            this.label2.Text = "1. MVC4 C# project with Oracle DataAccess version 4\r\n2. ADO Entity Data Model alr" +
    "eady generated\r\n3. Project must be closed";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(92, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Requirements :";
            // 
            // lblAfterRunningMessage
            // 
            this.lblAfterRunningMessage.AutoSize = true;
            this.lblAfterRunningMessage.Location = new System.Drawing.Point(357, 32);
            this.lblAfterRunningMessage.Name = "lblAfterRunningMessage";
            this.lblAfterRunningMessage.Size = new System.Drawing.Size(342, 78);
            this.lblAfterRunningMessage.TabIndex = 6;
            this.lblAfterRunningMessage.Text = resources.GetString("lblAfterRunningMessage.Text");
            this.lblAfterRunningMessage.Visible = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "C# project files|*.csproj";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(443, 139);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(256, 23);
            this.progressBar1.TabIndex = 7;
            this.progressBar1.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(1395, 156);
            this.label4.TabIndex = 8;
            this.label4.Text = resources.GetString("label4.Text");
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // btnFixEdmxIdentities
            // 
            this.btnFixEdmxIdentities.Location = new System.Drawing.Point(277, 187);
            this.btnFixEdmxIdentities.Name = "btnFixEdmxIdentities";
            this.btnFixEdmxIdentities.Size = new System.Drawing.Size(75, 23);
            this.btnFixEdmxIdentities.TabIndex = 9;
            this.btnFixEdmxIdentities.Text = "Fix Edmx Identities";
            this.btnFixEdmxIdentities.UseVisualStyleBackColor = true;
            this.btnFixEdmxIdentities.Click += new System.EventHandler(this.btnFixEdmxIdentities_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 367);
            this.Controls.Add(this.btnFixEdmxIdentities);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.lblAfterRunningMessage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnSelectProjectFile);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "XMvc Scaffolding for Oracle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSelectProjectFile;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblAfterRunningMessage;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button btnFixEdmxIdentities;
    }
}

